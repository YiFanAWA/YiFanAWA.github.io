(function () {
  const { mat4, vec3 } = glMatrix;

  const canvas = document.getElementById("gl-canvas");
  const gl = canvas.getContext("webgl2");
  if (!gl) {
    alert("WebGL2 not available");
    return;
  }

  // State for UI-driven parameters
  const state = {
    shading: "phong",
    ka: 0.2,
    kd: 0.8,
    ks: 0.6,
    shininess: 64.0,
    ambientColor: hexToRgb("#334155"),
    diffuseColor: hexToRgb("#5eead4"),
    specularColor: hexToRgb("#ffffff"),
    lightColor: hexToRgb("#ffffff"),
    lightPos: vec3.fromValues(2, 2, 2),
    eyePos: vec3.fromValues(0, 0, 4),
  };

  // Build geometry
  const sphere = buildSphere(48, 64);
  const vao = gl.createVertexArray();
  gl.bindVertexArray(vao);

  const positionBuffer = gl.createBuffer();
  gl.bindBuffer(gl.ARRAY_BUFFER, positionBuffer);
  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(sphere.positions), gl.STATIC_DRAW);

  const normalBuffer = gl.createBuffer();
  gl.bindBuffer(gl.ARRAY_BUFFER, normalBuffer);
  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(sphere.normals), gl.STATIC_DRAW);

  const indexBuffer = gl.createBuffer();
  gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, indexBuffer);
  gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, new Uint16Array(sphere.indices), gl.STATIC_DRAW);

  // Programs
  const programs = {
    phong: createProgram("phong-vertex-shader", "phong-fragment-shader"),
    gouraud: createProgram("gouraud-vertex-shader", "gouraud-fragment-shader"),
  };

  // Attribute/uniform lookups
  const programInfo = {};
  Object.keys(programs).forEach((key) => {
    const program = programs[key];
    programInfo[key] = {
      program,
      attribs: {
        position: gl.getAttribLocation(program, "aPosition"),
        normal: gl.getAttribLocation(program, "aNormal"),
      },
      uniforms: {
        model: gl.getUniformLocation(program, "uModel"),
        view: gl.getUniformLocation(program, "uView"),
        projection: gl.getUniformLocation(program, "uProjection"),
        normalMatrix: gl.getUniformLocation(program, "uNormalMatrix"),
        eyePos: gl.getUniformLocation(program, "uEyePos"),
        lightPos: gl.getUniformLocation(program, "uLightPos"),
        lightColor: gl.getUniformLocation(program, "uLightColor"),
        ambientColor: gl.getUniformLocation(program, "uAmbientColor"),
        diffuseColor: gl.getUniformLocation(program, "uDiffuseColor"),
        specularColor: gl.getUniformLocation(program, "uSpecularColor"),
        ka: gl.getUniformLocation(program, "uKa"),
        kd: gl.getUniformLocation(program, "uKd"),
        ks: gl.getUniformLocation(program, "uKs"),
        shininess: gl.getUniformLocation(program, "uShininess"),
      },
    };
  });

  gl.clearColor(0.04, 0.06, 0.12, 1.0);
  gl.enable(gl.DEPTH_TEST);

  const model = mat4.create();
  const view = mat4.create();
  const projection = mat4.create();
  const normalMatrix = mat4.create();

  mat4.lookAt(view, state.eyePos, [0, 0, 0], [0, 1, 0]);

  // UI wiring
  bindRange("ka", (v) => (state.ka = v));
  bindRange("kd", (v) => (state.kd = v));
  bindRange("ks", (v) => (state.ks = v));
  bindRange("shininess", (v) => (state.shininess = v));
  bindRange("lightX", (v) => (state.lightPos[0] = v));
  bindRange("lightY", (v) => (state.lightPos[1] = v));
  bindRange("lightZ", (v) => (state.lightPos[2] = v));

  bindColor("ambientColor", (rgb) => (state.ambientColor = rgb));
  bindColor("diffuseColor", (rgb) => (state.diffuseColor = rgb));
  bindColor("specularColor", (rgb) => (state.specularColor = rgb));
  bindColor("lightColor", (rgb) => (state.lightColor = rgb));

  document.querySelectorAll("input[name='shade']").forEach((input) => {
    input.addEventListener("change", () => {
      if (input.checked) {
        state.shading = input.value;
        updateStatus();
      }
    });
  });

  updateStatus();

  let lastTime = 0;
  function render(time) {
    const dt = (time - lastTime) * 0.001;
    lastTime = time;

    resize(gl);

    mat4.identity(model);
    mat4.rotateY(model, model, time * 0.0005);
    mat4.rotateX(model, model, 0.4);

    mat4.perspective(projection, Math.PI / 4, canvas.clientWidth / canvas.clientHeight, 0.1, 100.0);

    mat4.copy(normalMatrix, model);
    mat4.invert(normalMatrix, normalMatrix);
    mat4.transpose(normalMatrix, normalMatrix);

    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);

    const info = programInfo[state.shading];
    gl.useProgram(info.program);

    gl.bindVertexArray(vao);

    gl.bindBuffer(gl.ARRAY_BUFFER, positionBuffer);
    gl.enableVertexAttribArray(info.attribs.position);
    gl.vertexAttribPointer(info.attribs.position, 3, gl.FLOAT, false, 0, 0);

    gl.bindBuffer(gl.ARRAY_BUFFER, normalBuffer);
    gl.enableVertexAttribArray(info.attribs.normal);
    gl.vertexAttribPointer(info.attribs.normal, 3, gl.FLOAT, false, 0, 0);

    gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, indexBuffer);

    // Uniforms
    gl.uniformMatrix4fv(info.uniforms.model, false, model);
    gl.uniformMatrix4fv(info.uniforms.view, false, view);
    gl.uniformMatrix4fv(info.uniforms.projection, false, projection);
    gl.uniformMatrix4fv(info.uniforms.normalMatrix, false, normalMatrix);

    gl.uniform3fv(info.uniforms.eyePos, state.eyePos);
    gl.uniform3fv(info.uniforms.lightPos, state.lightPos);
    gl.uniform3fv(info.uniforms.lightColor, state.lightColor);

    gl.uniform3fv(info.uniforms.ambientColor, state.ambientColor);
    gl.uniform3fv(info.uniforms.diffuseColor, state.diffuseColor);
    gl.uniform3fv(info.uniforms.specularColor, state.specularColor);

    gl.uniform1f(info.uniforms.ka, state.ka);
    gl.uniform1f(info.uniforms.kd, state.kd);
    gl.uniform1f(info.uniforms.ks, state.ks);
    gl.uniform1f(info.uniforms.shininess, state.shininess);

    gl.drawElements(gl.TRIANGLES, sphere.indices.length, gl.UNSIGNED_SHORT, 0);

    requestAnimationFrame(render);
  }

  requestAnimationFrame(render);

  // --- helpers ---
  function createProgram(vsId, fsId) {
    const program = initShaders(gl, vsId, fsId);
    if (!program) {
      throw new Error("Failed to init program: " + vsId + "/" + fsId);
    }
    return program;
  }

  function buildSphere(stacks, slices) {
    const positions = [];
    const normals = [];
    const indices = [];

    for (let stack = 0; stack <= stacks; ++stack) {
      const v = stack / stacks;
      const phi = v * Math.PI;
      const cosPhi = Math.cos(phi);
      const sinPhi = Math.sin(phi);

      for (let slice = 0; slice <= slices; ++slice) {
        const u = slice / slices;
        const theta = u * Math.PI * 2;
        const cosTheta = Math.cos(theta);
        const sinTheta = Math.sin(theta);

        const x = cosTheta * sinPhi;
        const y = cosPhi;
        const z = sinTheta * sinPhi;

        positions.push(x, y, z);
        normals.push(x, y, z);
      }
    }

    for (let stack = 0; stack < stacks; ++stack) {
      for (let slice = 0; slice < slices; ++slice) {
        const first = stack * (slices + 1) + slice;
        const second = first + slices + 1;

        indices.push(first, second, first + 1);
        indices.push(second, second + 1, first + 1);
      }
    }

    return { positions, normals, indices };
  }

  function bindRange(id, setter) {
    const el = document.getElementById(id);
    const label = document.querySelector(`span[data-for="${id}"]`);
    const update = () => {
      const v = parseFloat(el.value);
      setter(v);
      if (label) label.textContent = v.toFixed( (id === "shininess") ? 0 : 2 );
      updateStatus();
    };
    el.addEventListener("input", update);
    update();
  }

  function bindColor(id, setter) {
    const el = document.getElementById(id);
    const update = () => setter(hexToRgb(el.value));
    el.addEventListener("input", update);
    update();
  }

  function hexToRgb(hex) {
    const v = parseInt(hex.slice(1), 16);
    const r = (v >> 16) & 255;
    const g = (v >> 8) & 255;
    const b = v & 255;
    return [r / 255, g / 255, b / 255];
  }

  function resize(glCtx) {
    const width = canvas.clientWidth;
    const height = canvas.clientHeight;
    if (canvas.width !== width || canvas.height !== height) {
      canvas.width = width;
      canvas.height = height;
    }
    glCtx.viewport(0, 0, canvas.width, canvas.height);
  }

  function updateStatus() {
    const status = document.getElementById("status-text");
    status.textContent = `Mode: ${state.shading.toUpperCase()}  |  Light: (${state.lightPos.map((v) => v.toFixed(1)).join(", ")})`;
  }
})();
