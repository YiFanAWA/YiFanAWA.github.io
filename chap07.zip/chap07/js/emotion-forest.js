import * as THREE from '../lib/three.module.js';
import { OrbitControls } from '../lib/OrbitControls.js';

console.log('[EmotionForest] init start');

const debugEl = document.createElement('div');
debugEl.id = 'debug-status';
debugEl.textContent = 'Loading...';
document.body.appendChild(debugEl);

function setDebug(text) {
  if (debugEl) debugEl.textContent = text;
  console.log('[EmotionForest]', text);
}

window.addEventListener('error', (e) => setDebug('Error: ' + (e.message || e.error)));
window.addEventListener('unhandledrejection', (e) => setDebug('Promise error: ' + (e.reason && e.reason.message ? e.reason.message : e.reason)));

const moods = {
  joy: {
    label: '喜悦 · Joy',
    copy: '金色阳光穿透树冠，花与尘埃在光柱中漂浮。',
    fogColor: 0xf2dfc2,
    bgColor: 0xf0d5a2,
    ambient: 0.8,
    dirIntensity: 1.2,
    dirColor: 0xffe0b3,
    hemiSky: 0xe6f4ff,
    hemiGround: 0x2c372a,
    ground: 0x2e5d38,
    foliage: 0x56b16b,
    flowers: 0xff87d5,
    water: 0x59c4ff,
    exposure: 1.08,
    particle: 'pollen',
    wind: 0.35,
    fogNear: 24,
    fogFar: 180,
  },
  calm: {
    label: '平静 · Calm',
    copy: '薄雾与微风划过水面，森林呼吸放缓。',
    fogColor: 0xcfe3ea,
    bgColor: 0x9ec8d8,
    ambient: 0.55,
    dirIntensity: 0.9,
    dirColor: 0xbfe1ff,
    hemiSky: 0xcde5ff,
    hemiGround: 0x2b3c38,
    ground: 0x2b4a42,
    foliage: 0x4d9c7d,
    flowers: 0xb5e5c7,
    water: 0x3f8fb8,
    exposure: 0.98,
    particle: 'breeze',
    wind: 0.18,
    fogNear: 20,
    fogFar: 150,
  },
  melancholy: {
    label: '忧郁 · Melancholy',
    copy: '阴云压顶的细雨落下，树叶暗哑，地面泛着湿光。',
    fogColor: 0x3b4552,
    bgColor: 0x1b2330,
    ambient: 0.32,
    dirIntensity: 0.6,
    dirColor: 0x9db4c6,
    hemiSky: 0x6c7d8a,
    hemiGround: 0x1a1e24,
    ground: 0x1f2a32,
    foliage: 0x2e4a3c,
    flowers: 0x7d8a96,
    water: 0x1b3343,
    exposure: 0.9,
    particle: 'rain',
    wind: 0.08,
    fogNear: 14,
    fogFar: 120,
  },
  longing: {
    label: '思念 · Longing',
    copy: '月光与萤火织出道路，引向一棵微光流动的古树。',
    fogColor: 0x0b1120,
    bgColor: 0x0b1021,
    ambient: 0.22,
    dirIntensity: 0.8,
    dirColor: 0xb3c8ff,
    hemiSky: 0x29344d,
    hemiGround: 0x0c0f16,
    ground: 0x121b24,
    foliage: 0x1f3a3b,
    flowers: 0x8ba0ff,
    water: 0x1b2e46,
    exposure: 0.95,
    particle: 'fireflies',
    wind: 0.12,
    fogNear: 18,
    fogFar: 160,
  },
};

const container = document.getElementById('scene-container');
const buttons = document.querySelectorAll('#emotion-buttons button');
const moodCopy = document.getElementById('mood-copy');

const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
renderer.setSize(container.clientWidth, container.clientHeight);
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
// Use legacy lights per r155 migration notice
renderer.useLegacyLights = true;
container.appendChild(renderer.domElement);

const scene = new THREE.Scene();
scene.fog = new THREE.Fog(moods.joy.fogColor, moods.joy.fogNear, moods.joy.fogFar);
scene.background = new THREE.Color(moods.joy.bgColor);
renderer.setClearColor(scene.background);

const camera = new THREE.PerspectiveCamera(50, container.clientWidth / container.clientHeight, 0.1, 400);
camera.position.set(0, 18, 60);

const controls = new OrbitControls(camera, renderer.domElement);
controls.enableDamping = true;
controls.enablePan = false;
controls.maxPolarAngle = Math.PI * 0.48;
controls.minDistance = 15;
controls.maxDistance = 120;

const ambientLight = new THREE.AmbientLight(0xffffff, moods.joy.ambient);
scene.add(ambientLight);

const hemiLight = new THREE.HemisphereLight(moods.joy.hemiSky, moods.joy.hemiGround, 0.35);
scene.add(hemiLight);

const dirLight = new THREE.DirectionalLight(moods.joy.dirColor, moods.joy.dirIntensity);
dirLight.position.set(30, 50, -24);
dirLight.castShadow = true;
dirLight.shadow.mapSize.set(2048, 2048);
dirLight.shadow.camera.near = 10;
dirLight.shadow.camera.far = 120;
dirLight.shadow.camera.left = -60;
dirLight.shadow.camera.right = 60;
dirLight.shadow.camera.top = 60;
dirLight.shadow.camera.bottom = -60;
scene.add(dirLight);

// Use explicit WebGLCubeRenderTarget to ensure mipmaps exist
const cubeRT = new THREE.WebGLCubeRenderTarget(256, { format: THREE.RGBAFormat, type: THREE.UnsignedByteType });
cubeRT.texture.generateMipmaps = true;
const cubeCamera = new THREE.CubeCamera(0.1, 500, cubeRT);
scene.add(cubeCamera);
// scene.environment will be set after first cubeCamera update

function buildGround() {
  const geo = new THREE.PlaneGeometry(240, 240, 1, 1);
  const mat = new THREE.MeshStandardMaterial({ color: moods.joy.ground, roughness: 0.92, metalness: 0.05 });
  const mesh = new THREE.Mesh(geo, mat);
  mesh.rotation.x = -Math.PI / 2;
  mesh.receiveShadow = true;
  scene.add(mesh);
  return mesh;
}


function buildWater() {
  const geo = new THREE.PlaneGeometry(48, 48, 90, 90);
  const mat = new THREE.MeshPhysicalMaterial({
    color: new THREE.Color(moods.joy.water),
    metalness: 0.9,
    roughness: 0.08,
    clearcoat: 0.6,
    envMapIntensity: 1.0,
  });
  const uniforms = { uTime: { value: 0 } };
  mat.onBeforeCompile = (shader) => {
    shader.uniforms.uTime = uniforms.uTime;
    shader.vertexShader = shader.vertexShader.replace('#include <common>', '#include <common>\nuniform float uTime;');
    shader.vertexShader = shader.vertexShader.replace(
      '#include <begin_vertex>',
      '#include <begin_vertex>\nfloat wave = sin(position.x * 0.16 + uTime * 0.8) * 0.2 + cos(position.y * 0.14 + uTime * 0.6) * 0.18;\ntransformed.z += wave;'
    );
  };
  const mesh = new THREE.Mesh(geo, mat);
  mesh.rotation.x = -Math.PI / 2;
  mesh.position.y = 0.22;
  mesh.receiveShadow = true;
  mesh.userData.uniforms = uniforms;
  scene.add(mesh);
  return mesh;
}

const shared = {
  trunkMat: new THREE.MeshStandardMaterial({ color: 0x3a2715, roughness: 0.9, metalness: 0.08 }),
  leafMat: new THREE.MeshStandardMaterial({ color: moods.joy.foliage, roughness: 0.7, metalness: 0.12 }),
};

const trees = [];
function buildTrees() {
  const group = new THREE.Group();
  for (let i = 0; i < 36; i++) {
    const radius = THREE.MathUtils.lerp(14, 82, Math.random());
    const angle = Math.random() * Math.PI * 2;
    const pos = new THREE.Vector3(Math.cos(angle) * radius, 0, Math.sin(angle) * radius);
    const scale = THREE.MathUtils.lerp(0.9, 1.6, Math.random());
    const tree = createTree(scale);
    tree.group.position.copy(pos);
    group.add(tree.group);
    trees.push(tree);
  }
  scene.add(group);
  return group;
}

function createTree(scale) {
  const trunkGeo = new THREE.CylinderGeometry(0.22, 0.28, 3.4, 8);
  const leafGeo = new THREE.ConeGeometry(1.4, 4.2, 10, 1, false);

  const trunk = new THREE.Mesh(trunkGeo, shared.trunkMat);
  trunk.castShadow = true;
  trunk.receiveShadow = true;

  const leaves = new THREE.Mesh(leafGeo, shared.leafMat);
  leaves.position.y = 2.6;
  leaves.castShadow = true;

  const group = new THREE.Group();
  group.add(trunk);
  group.add(leaves);
  group.scale.setScalar(scale);
  group.userData.phase = Math.random() * Math.PI * 2;

  return { group, trunk, leaves, baseScale: scale };
}

function buildAncientTree() {
  const geo = new THREE.ConeGeometry(3.6, 9.2, 16, 2, false);
  const barkGeo = new THREE.CylinderGeometry(0.9, 1.5, 5.2, 10);
  const barkMat = new THREE.MeshStandardMaterial({ color: 0x443322, roughness: 0.8, metalness: 0.1 });
  const leafMat = new THREE.MeshStandardMaterial({ color: 0x2f7563, roughness: 0.55, metalness: 0.18, emissive: 0x0b2232, emissiveIntensity: 0.6 });

  const bark = new THREE.Mesh(barkGeo, barkMat);
  bark.castShadow = true;
  bark.receiveShadow = true;
  const crown = new THREE.Mesh(geo, leafMat);
  crown.position.y = 5.4;
  crown.castShadow = true;

  const halo = new THREE.PointLight(0x77c6ff, 0.0, 32, 2.5);
  halo.position.set(0, 7.2, 0);

  const group = new THREE.Group();
  group.add(bark);
  group.add(crown);
  group.add(halo);
  group.position.set(-28, 0, 28);
  group.scale.setScalar(1.1);
  scene.add(group);
  group.userData.halo = halo;
  group.userData.crown = crown;
  return group;
}

function buildFlowers() {
  const count = 220;
  const geo = new THREE.SphereGeometry(0.35, 12, 12);
  const mat = new THREE.MeshStandardMaterial({ color: moods.joy.flowers, emissive: 0x111111, emissiveIntensity: 0.3, roughness: 0.45, metalness: 0.1 });
  const mesh = new THREE.InstancedMesh(geo, mat, count);
  mesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
  const dummy = new THREE.Object3D();
  for (let i = 0; i < count; i++) {
    const radius = THREE.MathUtils.lerp(10, 60, Math.random());
    const angle = Math.random() * Math.PI * 2;
    const x = Math.cos(angle) * radius;
    const z = Math.sin(angle) * radius;
    const y = 0.25 + Math.random() * 0.3;
    const scale = THREE.MathUtils.lerp(0.75, 1.4, Math.random());
    dummy.position.set(x, y, z);
    dummy.scale.setScalar(scale);
    dummy.updateMatrix();
    mesh.setMatrixAt(i, dummy.matrix);
  }
  mesh.castShadow = true;
  scene.add(mesh);
  return mesh;
}

function buildPollen() {
  const count = 650;
  const geo = new THREE.BufferGeometry();
  const positions = new Float32Array(count * 3);
  const seeds = new Float32Array(count);
  for (let i = 0; i < count; i++) {
    const r = THREE.MathUtils.lerp(4, 32, Math.random());
    const a = Math.random() * Math.PI * 2;
    positions[i * 3] = Math.cos(a) * r;
    positions[i * 3 + 1] = Math.random() * 6 + 1.5;
    positions[i * 3 + 2] = Math.sin(a) * r;
    seeds[i] = Math.random() * Math.PI * 2;
  }
  geo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
  geo.setAttribute('seed', new THREE.BufferAttribute(seeds, 1));
  const mat = new THREE.PointsMaterial({ size: 0.16, color: 0xffc878, transparent: true, opacity: 0.9, depthWrite: false, blending: THREE.AdditiveBlending });
  const points = new THREE.Points(geo, mat);
  points.visible = false;
  scene.add(points);
  return points;
}

function buildRain() {
  const count = 900;
  const geo = new THREE.BufferGeometry();
  const positions = new Float32Array(count * 3);
  const speeds = new Float32Array(count);
  for (let i = 0; i < count; i++) {
    positions[i * 3] = (Math.random() - 0.5) * 200;
    positions[i * 3 + 1] = Math.random() * 80 + 10;
    positions[i * 3 + 2] = (Math.random() - 0.5) * 200;
    speeds[i] = THREE.MathUtils.lerp(18, 32, Math.random());
  }
  geo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
  geo.setAttribute('speed', new THREE.BufferAttribute(speeds, 1));
  const mat = new THREE.PointsMaterial({ size: 0.08, color: 0xa9c6ff, transparent: true, opacity: 0.85, depthWrite: false });
  const points = new THREE.Points(geo, mat);
  points.visible = false;
  scene.add(points);
  return points;
}

function buildFireflies(target) {
  const count = 160;
  const geo = new THREE.BufferGeometry();
  const positions = new Float32Array(count * 3);
  const offsets = new Float32Array(count);
  for (let i = 0; i < count; i++) offsets[i] = Math.random();
  geo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
  geo.setAttribute('offset', new THREE.BufferAttribute(offsets, 1));
  const mat = new THREE.PointsMaterial({ size: 0.18, color: 0x9dd6ff, transparent: true, opacity: 0.95, blending: THREE.AdditiveBlending, depthWrite: false });
  const points = new THREE.Points(geo, mat);
  points.visible = false;
  scene.add(points);

  const curve = new THREE.CatmullRomCurve3([
    new THREE.Vector3(20, 0.6, -24),
    new THREE.Vector3(10, 1.8, -4),
    new THREE.Vector3(-6, 2.2, 8),
    new THREE.Vector3(-16, 2.6, 18),
    target.clone().add(new THREE.Vector3(0, 2.8, 0)),
  ], false, 'centripetal');

  points.userData.curve = curve;
  return points;
}

function updateMoodUI() {
  const data = moods[targetMood];
  moodCopy.textContent = `${data.label} · ${data.copy}`;
}

function onResize() {
  const { clientWidth, clientHeight } = container;
  renderer.setSize(clientWidth, clientHeight);
  camera.aspect = clientWidth / clientHeight;
  camera.updateProjectionMatrix();
}

function loop() {
  const dt = clock.getDelta();
  const t = clock.elapsedTime;
  controls.update();

  smoothTransition(dt);
  updateTrees(t, dt);
  updatePollen(dt, t);
  updateRain(dt);
  updateFireflies(dt, t);
  updateWater(t);

  if (frame % 2 === 0) {
    water.visible = false;
    cubeCamera.update(renderer, scene);
    water.visible = true;
    // After first update, set scene.environment so materials can reflect
    if (!scene.environment) {
      scene.environment = cubeRT.texture;
    }
  }

  renderer.render(scene, camera);
  frame++;
  requestAnimationFrame(loop);
}

setDebug('Loop scheduled');

function smoothTransition(dt) {
  const target = moods[targetMood];
  const lerp = (start, end, speed) => THREE.MathUtils.lerp(start, end, 1 - Math.exp(-speed * dt));

  scene.fog.color.lerp(new THREE.Color(target.fogColor), 1 - Math.exp(-1.8 * dt));
  scene.background.lerp(new THREE.Color(target.bgColor), 1 - Math.exp(-1.8 * dt));
  scene.fog.near = lerp(scene.fog.near, target.fogNear, 4.5);
  scene.fog.far = lerp(scene.fog.far, target.fogFar, 4.5);

  ambientLight.intensity = lerp(ambientLight.intensity, target.ambient, 4.5);
  hemiLight.color.lerp(new THREE.Color(target.hemiSky), 1 - Math.exp(-3 * dt));
  hemiLight.groundColor.lerp(new THREE.Color(target.hemiGround), 1 - Math.exp(-3 * dt));
  dirLight.intensity = lerp(dirLight.intensity, target.dirIntensity, 4.5);
  dirLight.color.lerp(new THREE.Color(target.dirColor), 1 - Math.exp(-3 * dt));

  renderer.toneMappingExposure = lerp(renderer.toneMappingExposure, target.exposure, 3.6);

  shared.leafMat.color.lerp(new THREE.Color(target.foliage), 1 - Math.exp(-3 * dt));
  shared.trunkMat.color.lerp(new THREE.Color(0x3a2715), 1 - Math.exp(-3 * dt));
  ground.material.color.lerp(new THREE.Color(target.ground), 1 - Math.exp(-3 * dt));
  flowers.material.color.lerp(new THREE.Color(target.flowers), 1 - Math.exp(-3 * dt));
  water.material.color.lerp(new THREE.Color(target.water), 1 - Math.exp(-3 * dt));
  water.material.envMapIntensity = lerp(water.material.envMapIntensity, target === moods.melancholy ? 0.8 : 1.2, 4.0);

  ancientTree.userData.halo.intensity = lerp(
    ancientTree.userData.halo.intensity,
    targetMood === 'longing' ? 3.8 : 0.0,
    6.0
  );
  ancientTree.userData.crown.material.emissiveIntensity = lerp(
    ancientTree.userData.crown.material.emissiveIntensity,
    targetMood === 'longing' ? 0.85 : 0.4,
    5.0
  );

  const particleMode = target.particle;
  pollen.visible = particleMode === 'pollen' || particleMode === 'breeze';
  rain.visible = particleMode === 'rain';
  fireflies.visible = particleMode === 'fireflies';

  currentMood = targetMood;
}

function updateTrees(t, dt) {
  const target = moods[targetMood];
  trees.forEach((tree) => {
    const sway = Math.sin(t * 0.6 + tree.group.userData.phase) * 0.008 * target.wind;
    tree.group.rotation.z = THREE.MathUtils.lerp(tree.group.rotation.z, sway, 0.5);
    const scaleTarget = tree.baseScale * (targetMood === 'joy' ? 1.1 : targetMood === 'melancholy' ? 0.95 : targetMood === 'longing' ? 1.05 : 1.0);
    const s = THREE.MathUtils.lerp(tree.group.scale.x, scaleTarget, 1 - Math.exp(-3.5 * dt));
    tree.group.scale.setScalar(s);
  });
}

function updatePollen(dt, t) {
  if (!pollen.visible) return;
  const pos = pollen.geometry.attributes.position.array;
  const seed = pollen.geometry.attributes.seed.array;
  for (let i = 0; i < seed.length; i++) {
    const idx = i * 3;
    const lift = 0.9 + Math.sin(t * 0.8 + seed[i]) * 0.25;
    pos[idx + 1] += dt * (1.2 + lift);
    pos[idx] += Math.sin(t * 0.6 + seed[i]) * dt * 0.9;
    pos[idx + 2] += Math.cos(t * 0.5 + seed[i]) * dt * 0.9;
    if (pos[idx + 1] > 14) {
      pos[idx + 1] = 1.2 + Math.random() * 2.2;
      pos[idx] = (Math.random() - 0.5) * 70;
      pos[idx + 2] = (Math.random() - 0.5) * 70;
    }
  }
  pollen.geometry.attributes.position.needsUpdate = true;
}

function updateRain(dt) {
  if (!rain.visible) return;
  const pos = rain.geometry.attributes.position.array;
  const speed = rain.geometry.attributes.speed.array;
  for (let i = 0; i < speed.length; i++) {
    const idx = i * 3;
    pos[idx + 1] -= speed[i] * dt;
    if (pos[idx + 1] < -2) {
      pos[idx + 1] = 80 + Math.random() * 20;
      pos[idx] = (Math.random() - 0.5) * 200;
      pos[idx + 2] = (Math.random() - 0.5) * 200;
    }
  }
  rain.geometry.attributes.position.needsUpdate = true;
}

function updateFireflies(dt, t) {
  if (!fireflies.visible) return;
  const curve = fireflies.userData.curve;
  const pos = fireflies.geometry.attributes.position.array;
  const offset = fireflies.geometry.attributes.offset.array;
  for (let i = 0; i < offset.length; i++) {
    const idx = i * 3;
    const u = (t * 0.05 + offset[i]) % 1;
    const base = curve.getPointAt(u);
    pos[idx] = base.x + Math.sin(t * 1.2 + offset[i] * 10) * 0.9;
    pos[idx + 1] = base.y + 1.2 + Math.sin(t * 2.1 + offset[i] * 8) * 0.6;
    pos[idx + 2] = base.z + Math.cos(t * 1.1 + offset[i] * 7) * 0.9;
  }
  fireflies.geometry.attributes.position.needsUpdate = true;
}

function updateWater(t) {
  water.userData.uniforms.uTime.value = t;
}

// ---- Top-level initialization moved here to avoid TDZ issues ----
let currentMood = 'joy';
let targetMood = 'joy';
let frame = 0;
const clock = new THREE.Clock();

const ground = buildGround();
const water = buildWater();
const treeLayer = buildTrees();
const ancientTree = buildAncientTree();
const flowers = buildFlowers();
const pollen = buildPollen();
const rain = buildRain();
const fireflies = buildFireflies(ancientTree.position.clone());

updateMoodUI();
buttons.forEach((b) => b.classList.toggle('active', b.dataset.mood === targetMood));

buttons.forEach((btn) => {
  btn.addEventListener('click', () => {
    const mood = btn.dataset.mood;
    targetMood = mood;
    buttons.forEach((b) => b.classList.toggle('active', b.dataset.mood === mood));
    updateMoodUI();
  });
});

window.addEventListener('resize', onResize);
requestAnimationFrame(loop);
setDebug('Scene initialized');
