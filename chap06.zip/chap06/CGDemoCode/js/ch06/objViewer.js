"use strict";
const { mat4, vec3 } = glMatrix;

window.addEventListener('load', function () {
  const canvas = document.getElementById('gl-canvas');
  const gl = canvas.getContext('webgl2');
  if (!gl) { alert('WebGL2 not available — this demo requires a WebGL2-capable browser'); return; }

  const program = initShaders(gl, 'vertex-shader', 'fragment-shader');
  gl.useProgram(program);

  // attrib/uniform locations
  const aPos = gl.getAttribLocation(program, 'a_position');
  const aNormal = gl.getAttribLocation(program, 'a_normal');
  const uMatrix = gl.getUniformLocation(program, 'u_matrix');
  const uNormalMatrix = gl.getUniformLocation(program, 'u_normalMatrix');
  const uLightDir = gl.getUniformLocation(program, 'u_lightDir');
  const uColor = gl.getUniformLocation(program, 'u_color');

  // simple cube OBJ (vertices + faces). Using OBJ.Mesh parser.
  const cubeOBJ = `
v -1 -1 -1
v 1 -1 -1
v 1 1 -1
v -1 1 -1
v -1 -1 1
v 1 -1 1
v 1 1 1
v -1 1 1

f 1 2 3
f 3 4 1

f 5 8 7
f 7 6 5

f 1 5 6
f 6 2 1

f 2 6 7
f 7 3 2

f 3 7 8
f 8 4 3

f 4 8 5
f 5 1 4
`;

  const mesh = new OBJ.Mesh(cubeOBJ);
  OBJ.initMeshBuffers(gl, mesh);

  // create edge index buffer for wireframe
  const edgeIndices = [];
  const seen = {};
  for (let i = 0; i < mesh.indices.length; i += 3) {
    const a = mesh.indices[i];
    const b = mesh.indices[i + 1];
    const c = mesh.indices[i + 2];
    [[a,b],[b,c],[c,a]].forEach(pair => {
      const p = pair.slice().sort((x,y)=>x-y).join('-');
      if (!seen[p]) { seen[p] = true; edgeIndices.push(pair[0], pair[1]); }
    });
  }
  const edgeBuffer = gl.createBuffer();
  gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, edgeBuffer);
  gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, new Uint16Array(edgeIndices), gl.STATIC_DRAW);

  // state
  const state = {
    mode: 'solid', // 'wire' or 'solid'
    proj: 'persp',
    tx: 0, ty: 0, tz: 0,
    rx: 0, ry: 0, rz: 0,
    s: 1,
    fov: 60 * Math.PI / 180,
    znear: 0.1,
    zfar: 100,
    camDist: 6
  };

  // UI bindings
  function $(id){return document.getElementById(id)}
  function bindRange(id, key, cb){
    const el = $(id);
    el.addEventListener('input', () => { state[key] = parseFloat(el.value); if(cb) cb(); });
  }
  bindRange('mTx','tx'); bindRange('mTy','ty'); bindRange('mTz','tz');
  bindRange('mRx','rx'); bindRange('mRy','ry'); bindRange('mRz','rz'); bindRange('mS','s');
  bindRange('fov','fov', ()=>{$('fovv').textContent = $('fov').value});
  // fov slider stores degrees; convert later
  bindRange('camDist','camDist');
  $('fov').addEventListener('input', ()=> state.fov = parseFloat($('fov').value) * Math.PI/180 );
  $('znear').addEventListener('change', ()=> state.znear = parseFloat($('znear').value));
  $('zfar').addEventListener('change', ()=> state.zfar = parseFloat($('zfar').value));

  document.querySelectorAll('input[name=mode]').forEach(r => r.addEventListener('change', e=> state.mode = e.target.value));
  document.querySelectorAll('input[name=proj]').forEach(r => r.addEventListener('change', e=> state.proj = e.target.value));
  $('resetBtn').addEventListener('click', ()=>{
    ['mTx','mTy','mTz'].forEach(id=>$(id).value='0');
    ['mRx','mRy','mRz'].forEach(id=>$(id).value='0');
    $('mS').value='1'; $('fov').value='60'; $('camDist').value='6'; $('znear').value='0.1'; $('zfar').value='100';
    state.tx=state.ty=state.tz=0; state.rx=state.ry=state.rz=0; state.s=1; state.fov=60*Math.PI/180; state.camDist=6; state.znear=0.1; state.zfar=100;
  });

  // gl enable
  gl.enable(gl.DEPTH_TEST);

  function draw(){
    gl.viewport(0,0,canvas.width,canvas.height);
    gl.clearColor(0.95,0.95,0.95,1);
    gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);

    gl.useProgram(program);

    // bind attributes
    gl.bindBuffer(gl.ARRAY_BUFFER, mesh.vertexBuffer);
    gl.enableVertexAttribArray(aPos);
    gl.vertexAttribPointer(aPos, mesh.vertexBuffer.itemSize, gl.FLOAT, false, 0, 0);

    gl.bindBuffer(gl.ARRAY_BUFFER, mesh.normalBuffer);
    gl.enableVertexAttribArray(aNormal);
    gl.vertexAttribPointer(aNormal, mesh.normalBuffer.itemSize, gl.FLOAT, false, 0, 0);

    // compute matrices
    const proj = mat4.create();
    const aspect = canvas.width / canvas.height;
    if (state.proj === 'persp') {
      mat4.perspective(proj, state.fov, aspect, state.znear, state.zfar);
    } else {
      const s = 3.0;
      mat4.ortho(proj, -s*aspect, s*aspect, -s, s, state.znear, state.zfar);
    }

    const view = mat4.create();
    const eye = [0,0,state.camDist];
    mat4.lookAt(view, eye, [0,0,0], [0,1,0]);

    // model
    const model = mat4.create();
    mat4.translate(model, model, [state.tx, state.ty, state.tz]);
    mat4.rotateX(model, model, state.rx * Math.PI/180);
    mat4.rotateY(model, model, state.ry * Math.PI/180);
    mat4.rotateZ(model, model, state.rz * Math.PI/180);
    mat4.scale(model, model, [state.s, state.s, state.s]);

    const mv = mat4.create();
    mat4.multiply(mv, view, model);
    const mvp = mat4.create();
    mat4.multiply(mvp, proj, mv);

    gl.uniformMatrix4fv(uMatrix, false, mvp);

    // normal matrix: inverse transpose of mv
    const normalMat = mat4.create();
    mat4.invert(normalMat, mv);
    mat4.transpose(normalMat, normalMat);
    gl.uniformMatrix4fv(uNormalMatrix, false, normalMat);

    gl.uniform3fv(uLightDir, vec3.normalize([], [0.5, 0.7, 1]));
    gl.uniform4fv(uColor, [0.6, 0.6, 0.85, 1.0]);

    if (state.mode === 'solid'){
      gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, mesh.indexBuffer);
      gl.drawElements(gl.TRIANGLES, mesh.indexBuffer.numItems, gl.UNSIGNED_SHORT, 0);
    } else {
      gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, edgeBuffer);
      gl.drawElements(gl.LINES, edgeIndices.length, gl.UNSIGNED_SHORT, 0);
    }
  }

  function tick(){ draw(); requestAnimationFrame(tick); }
  tick();
});
