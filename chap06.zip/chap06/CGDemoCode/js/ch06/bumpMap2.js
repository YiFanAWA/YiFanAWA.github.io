"use strict";

const{ vec2, vec3, vec4, mat3, mat4 }= glMatrix;

var canvas;
var gl;

var theta = 0.0;
var phi = 0.0;
var dr = 5.0 * Math.PI/180.0;

var texSize = 256;

// Bump Data

var data = new Array()
    for (var i = 0; i<= texSize; i++)  data[i] = new Array();
    for (var i = 0; i<= texSize; i++) for (var j=0; j<=texSize; j++)
        data[i][j] = rawData[i*256+j];


// Bump Map Normals

var normalst = new Array()
    for (var i=0; i<texSize; i++)  normalst[i] = new Array();
    for (var i=0; i<texSize; i++) for ( var j = 0; j < texSize; j++)
        normalst[i][j] = new Array();
    for (var i=0; i<texSize; i++) for ( var j = 0; j < texSize; j++) {
        normalst[i][j][0] = data[i][j]-data[i+1][j];
        normalst[i][j][1] = data[i][j]-data[i][j+1];
        normalst[i][j][2] = 1;
    }

// Scale to Texture Coordinates

    for (var i=0; i<texSize; i++) for (var j=0; j<texSize; j++) {
       var d = 0;
       for(k=0;k<3;k++) d+=normalst[i][j][k]*normalst[i][j][k];
       d = Math.sqrt(d);
       for(k=0;k<3;k++) normalst[i][j][k]= 0.5*normalst[i][j][k]/d + 0.5;
    }

// Normal Texture Array

var normals = new Uint8Array(3*texSize*texSize);

    for (var i = 0; i < texSize; i++)
        for (var j = 0; j < texSize; j++)
           for(var k =0; k<3; k++)
                normals[3*texSize*i+3*j+k] = 255*normalst[i][j][k];


var positionsArray = [];
var texCoordsArray = [];

var texCoord = [
    0, 0,
    1, 0,
    1, 1,
    0, 1
];

var vertices = [
    0.0, 0.0, 0.0,
    1.0,  0.0,  0.0,
    1.0,  0.0,  1.0,
    0.0, 0.0,  1.0
];

var indices = [
	0, 1, 
	3, 2
];

var modelViewMatrix, projectionMatrix, nMatrix;


var normal = vec4.fromValues(0.0, 1.0, 0.0, 0.0);
var tangent = vec3.fromValues(1.0, 0.0, 0.0);

var lightDiffuse = vec4.fromValues(1.0, 1.0, 1.0, 1.0);

var materialDiffuse = vec4.fromValues(0.7, 0.7, 0.7, 1.0);

var program;

function configureTexture( image ) {
    var texture = gl.createTexture();
    gl.activeTexture(gl.TEXTURE0);
    gl.bindTexture(gl.TEXTURE_2D, texture);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGB, texSize, texSize, 0, gl.RGB, gl.UNSIGNED_BYTE, image);
    gl.generateMipmap(gl.TEXTURE_2D);
}

function mesh() {
    for(var i=0; i<indices.length; i++)
	{
		var index = indices[i];
		positionsArray.push(vertices[index*3], vertices[index*3+1], vertices[index*3+2]);
		texCoordsArray.push(texCoord[index*2], texCoord[index*2+1]);
	}
}

window.onload = function init() {

    canvas = document.getElementById( "gl-canvas" );

    gl = canvas.getContext('webgl2');
    if (!gl) { alert( "WebGL 2.0 isn't available" ); }

    gl.viewport( 0, 0, canvas.width, canvas.height );
    gl.clearColor( 1.0, 1.0, 1.0, 1.0 );

    gl.enable(gl.DEPTH_TEST);

    //
    //  Load shaders and initialize attribute buffers
    //
    program = initShaders(gl, "vertex-shader", "fragment-shader");
    gl.useProgram(program);

    mesh();

    var vBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, vBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(positionsArray), gl.STATIC_DRAW);

    var positionLoc = gl.getAttribLocation(program, "aPosition");
    gl.vertexAttribPointer(positionLoc, 3, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(positionLoc);

    var tBuffer = gl.createBuffer();
    gl.bindBuffer( gl.ARRAY_BUFFER, tBuffer);
    gl.bufferData( gl.ARRAY_BUFFER, new Float32Array(texCoordsArray), gl.STATIC_DRAW);

    var texCoordLoc = gl.getAttribLocation( program, "aTexCoord");
    gl.vertexAttribPointer( texCoordLoc, 2, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(texCoordLoc);

    configureTexture(normals);

    var diffuseProduct = vec4.create();
	vec4.multiply(diffuseProduct, lightDiffuse, materialDiffuse);

    gl.uniform4fv( gl.getUniformLocation(program, "uDiffuseProduct"), diffuseProduct);
    gl.uniform4fv( gl.getUniformLocation(program, "uNormal"), normal);
    gl.uniform3fv( gl.getUniformLocation(program, "uObjTangent"), tangent);

    document.getElementById("Button2").onclick = function(){theta += dr;};
    document.getElementById("Button3").onclick = function(){theta -= dr;};
    document.getElementById("Button4").onclick = function(){phi += dr;};
    document.getElementById("Button5").onclick = function(){phi -= dr;};

    render();
}

var render = function() {

    gl.clear( gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);

    var lightPosition = vec4.fromValues(0.0, 2.0, 0.0, 1.0 );

    lightPosition[1] = 1.0 * Math.cos(theta);
	theta+=0.01;
    gl.uniform4fv( gl.getUniformLocation(program, "uLightPosition"), lightPosition);

    var eye = vec3.fromValues(1.0, 1.5*(1.0+Math.cos(phi)), 1.0);
    var at = vec3.fromValues(0.0, 0.0, 0.0);
    var up = vec3.fromValues(0.0, 1.0, 0.0);

    modelViewMatrix = mat4.create();
	mat4.lookAt(modelViewMatrix, eye, at, up);
	//modelViewMatrix  = lookAt(eye, at, up);
	projectionMatrix = mat4.create();
    mat4.ortho(projectionMatrix, -1.2, 1.2, -1.2, 1.2,-10.0,10.0);

  	var nMatrix = mat3.create();
	nMatrix = mat3.fromValues( modelViewMatrix[0], modelViewMatrix[4], modelViewMatrix[8], modelViewMatrix[1], modelViewMatrix[5], modelViewMatrix[9],modelViewMatrix[2], modelViewMatrix[6], modelViewMatrix[10] );
	//mat3.normalFromMat4(nMatrix, modelViewMatrix);
	mat3.transpose(nMatrix, nMatrix);

    gl.uniformMatrix4fv( gl.getUniformLocation(program, "uModelViewMatrix"), false, new Float32Array(modelViewMatrix));
    gl.uniformMatrix4fv( gl.getUniformLocation(program, "uProjectionMatrix"), false, new Float32Array(projectionMatrix));
    gl.uniformMatrix3fv( gl.getUniformLocation(program, "uNormalMatrix"), false, new Float32Array(nMatrix));

    gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);

    requestAnimationFrame(render);
}
