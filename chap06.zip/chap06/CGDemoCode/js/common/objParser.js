/**
 * Parser for .obj files
 */

 var objParser = {
    reset: function(){
        this.vertices = [];
        this.faces = [];
        this.normals = [];
        this.texCoords = [];

        this.vnormals = [];
        this.vtexCoords = [];
    },
    'v': function( x, y, z ){
        // vertex
        this.vertices.push( +x, +y, +z );
    },
    'f': function( v1, v2, v3 ){
        var v = v1.split('/');
        if( v.length > 0){
            var fv1 = v1.split('/')[0];
            var fv2 = v2.split('/')[0];
            var fv3 = v3.split('/')[0];
            this.faces.push( +fv1 - 1, +fv2 - 1, +fv3 -1 ); // convert 1-based to 0-based
        }
        if( v.length > 1 && v[1] != "" ){
            var vn1 = v1.split('/')[1];
            var vn2 = v2.split('/')[1];
            var vn3 = v3.split('/')[1];
            this.vtexCoords.push( +vn1 - 1, +vn2 - 1, +vn3 - 1 );
        }
        if( v.length > 2 ){
            var vt1 = v1.split('/')[2];
            var vt2 = v2.split('/')[2];
            var vt3 = v3.split('/')[2];
            this.vnormals.push( +vt1 - 1, +vt2 - 1, +vt3 - 1 );   
        }
    },
    'o': function(){
        /* obj name, just ignore */
    },
    'g': function(){
        /* groups, just ignore */
    },
    '#': function(){
        /* comment, just ignore */
    },
    'vn': function( x, y, z ){
        // vertex normals
        this.normals.push( +x, +y, +z );
    },
    'vt': function( x, y ){
        this.texCoords.push( +x, +y );
    }
 };

 /**
  * call this function to load a .obj file from a url and then parse it into an object
  * 
  * @returns {vertices: <array of vertex coords>, faces: <array of vertex indices>, normals: <arrays of normal vectors>, texCoords: <arrays of texture coordinates>
  *             vnormals: <arrays of normal indices>, vtexCoords: <arrays of texture coordinates indices>}
  */
function loadObjFile( url ){
    var objString = loadTextFile( url );
    var lines = objString.split('\n');
    objParser.reset();

    lines.forEach( function( line ){
        if( line.length === 0 ){
            return;
        }
        var components = line.split(/ +/);
        var type = components[0];
        try{
            objParser[type].apply(objParser, components.slice(1));
        }catch(e){
            console.warn('Unknown obj command type: "' + type + '"', e.toString());
        }
    });

    return { vertices: objParser.vertices, faces: objParser.faces, normals: objParser.normals, texCoords: objParser.texCoords, vnormals: objParser.vnormals, vtexCoords: objParser.vtexCoords };
}

/**
 * load a text file synchronously through XMLHttpRequest 
 */
function loadTextFile( url ){
    var request = new XMLHttpRequest();
    request.open('GET', url, false);
    request.send();
    return request.responseText;
}

/**
 * Compute the per-vertex surface normal for the given set of vertices and faces.
 */

 function computeNormals( v, f ){
     var normals = new Float32Array(v.length);

     for( var i = 0, count = f.length; i < count; i += 3){
        var v1 = f[i] * 3, v2 = f[i+1]*3, v3 = f[i+2]*3;
        var normal = getNormal(v[v1], v[v1+1], v[v1+2], v[v2], v[v2+1], v[v2+2], v[v3], v[v3+1], v[v3+2]);

        normals[v1] += normal[0];
        normals[v1+1] += normal[1];
        normals[v1+2] += normal[2];

        normals[v2] += normal[0];
        normals[v2+1] += normal[1];
        normals[v2+2] += normal[2];

        normals[v3] += normal[0];
        normals[v3+1] += normal[1];
        normals[v3+2] += normal[2];
     }
     return normals;
 }

 function getNormal( v1x, v1y, v1z, v2x, v2y, v2z, v3x, v3y, v3z ){
     var normal = new Float32Array(3);
     var ux = v2x - v1x, uy = v2y - v1y, uz = v2z - v1z;
     var vx = v3x - v1x, vy = v3y - v1y, vz = v3z - v1z;

     normal[0] = uy * vz - uz * vy;
     normal[1] = uz * vx - ux * vz;
     normal[2] = ux * vy - uy * vx;

     return normal;
 }